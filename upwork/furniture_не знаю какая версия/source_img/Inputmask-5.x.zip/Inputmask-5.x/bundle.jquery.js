import Inputmask from "./bundle";
import "./lib/jquery.inputmask";

export default Inputmask;

